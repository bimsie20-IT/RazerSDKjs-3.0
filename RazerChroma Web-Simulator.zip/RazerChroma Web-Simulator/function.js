const l = {
    1: ["esc", "N1_1", "F1", "F2", "F3", "F4", "N1_2", "F5", "F6", "F7", "F8", "N1_3", "F9", "F10", "F11", "F12", "DS", "rln", "PU", "N1_4", "N1_5", "N1_6", "N1_7", "N1_8",],
    2: ["^", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "ß", "`", "<-_1", "<-_2", "N2_1", "ef", "P1", "B^", "N2_2", "num", "/", "star", "line",],
    3: ["<-->", "Q", "W", "E", "R", "T", "Z", "U", "I", "O", "P", "Ü", "+3_1", "|<-3_1", "|<-3_2", "N3_1", "enf", "end", "B^d", "N3_2", "7P", "8∧", "9B^", "+3_2",],
    4: ["⇩", "A", "S", "D", "F", "G", "H", "J", "K", "L", "Ö", "Ä", "#", "|<-4_1", "|<-4_2", "N4_1", "N4_2", "N4_3", "N4_4", "N4_5", "4<", "5.", "6>", "+4_1",],
    5: ["⇧5_1", "<5_1", "Y", "X", "C", "V", "B", "N", "M", ";", ":", "_", "⇧5_2", "⇧5_3", "⇧5_4", "N5_1", "N5_2", "∧", "N5_3", "N5_4", "1E", "2∨", "3B^", "ent5_1",],
    6: ["strg6_1", "⊞", "alt", "Space6_1", "Space6_2", "Space6_3", "Space6_4", "Space6_5", "Space6_6", "Space6_7", "AG", "fn", "⊟", "strg6_2", "strg6_3", "N2_1", "<6_1", "∨", ">", "N2_2", "0E6_1", "0E6_2", "/E", "ent6_1",]
};

const End = {
    1: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ],
    2: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ],
    3: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ],
    4: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ],
    5: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ],
    6: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ]
};

//The color-code has to be changed in order to be readable by the Razer Synapse "REST-API"
function RgbHex_to_BgrDec(rgbHEXcolor) {
    if (!rgbHEXcolor) {  //There is a bug in this program that sometimes the parameter gives a "0" instead of a color-code
        rgbHEXcolor = "#000000";  //The "0" will then be replaced with "black" ("#000000")
    }

    //Slicing the value of "red", "green" and "blue"
    const RED = (rgbHEXcolor.toString()).slice(1, 3);
    const GREEN = (rgbHEXcolor.toString()).slice(3, 5);
    const BLUE = (rgbHEXcolor.toString()).slice(5, 7);

    //Changing the color-order: RGB -> ("red" + "green" + "blue") to  BGR -> ("blue" + "green" + "red")
    const bgrHEXcolor = BLUE + GREEN + RED;
    const bgrDECcolor = parseInt(bgrHEXcolor, 16);

    return bgrDECcolor;
};

function custom_colors_vr(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x) {
    let colors = {
            1: [ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x ],
            2: [ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x ],
            3: [ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x ],
            4: [ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x ],
            5: [ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x ],
            6: [ a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x ]
    };
    return colors;
};

function custom_colors_hr(a,b,c,d,e,f) {
    let colors = {
            1: [ a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a ],
            2: [ b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b,b ],
            3: [ c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c,c ],
            4: [ d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d ],
            5: [ e,e,e,e,e,e,e,e,e,e,e,e,e,e,e,e,e,e,e,e,e,e,e,e ],
            6: [ f,f,f,f,f,f,f,f,f,f,f,f,f,f,f,f,f,f,f,f,f,f,f,f ]
    };
    return colors;
};



function start_cycle() {
    try {
        const restAPI = new XMLHttpRequest();
        restAPI.onload = function() {
            const response = JSON.parse(this.responseText);
            //The "sessionid" is used for authentication for the next requests
            sessionid = response.sessionid;
        };
        restAPI.open("POST", "http://localhost:54235/razer/chromasdk");
        restAPI.setRequestHeader("Content-type", "application/json");

        const RCobject = {
            "title": "Razer Chroma Preview",
            "description": "An online simulator to show some very neat things you can do with your clicking board!",
            "author": {
                "name": "Lars Thysen",
                "contact": "edwin.thyse@gmail.com"
            },
            "device_supported": ["keyboard"],
            "category": "application"
        };
        const RCjson = JSON.stringify(RCobject);

        restAPI.send(RCjson);
    }
    catch {
        console.log("Razer Synapse not detected");
    };
};

function end_cycle() {
    try {
        const restAPI = new XMLHttpRequest();
        restAPI.open("DELETE", "http://localhost:"+sessionid+"/chromasdk");
        restAPI.send();
    }
    catch {
        console.log("Razer Synapse not detected");
    };
};

function PUT_requests(stage_effect) {

    const keyboard_vertical_index = 1;
    let Vi = keyboard_vertical_index;     //There have to be 6 vertical indexes changed of 24 buttons
    for (index in stage_effect) {

        const keyboard_horizontal_index = 0;
        let Hi = keyboard_horizontal_index;
        for (LED in stage_effect[Vi]) {          //Changing the button colors one by one
            document.getElementById(l[Vi][Hi]).style.backgroundColor = stage_effect[Vi][Hi];
            Hi += 1;
        };
        Vi += 1;
    };  



    try {
        //Putting the colors at the right place, but now in real life (not the simulated keyboard on the webpage)
        function SE(Vi, Hi) {const color = RgbHex_to_BgrDec(stage_effect[Vi][Hi]); return color;}  // RGB(16) to BGR(10) function
        const RCobject = {
            "effect": "CHROMA_CUSTOM",
            "param":[
            [ SE(1, 0),SE(1, 1),SE(1, 2),SE(1, 3),SE(1, 4),SE(1, 5),SE(1, 6),SE(1, 7),SE(1, 8),SE(1, 9),SE(1, 10),SE(1, 11),SE(1, 12),SE(1, 13),SE(1, 14),SE(1, 15),SE(1, 16),SE(1, 17),SE(1, 18),SE(1, 19),SE(1, 20),SE(1, 21) ],
            [ SE(2, 0),SE(2, 1),SE(2, 2),SE(2, 3),SE(2, 4),SE(2, 5),SE(2, 6),SE(2, 7),SE(2, 8),SE(2, 9),SE(2, 10),SE(2, 11),SE(2, 12),SE(2, 13),SE(2, 14),SE(2, 15),SE(2, 16),SE(2, 17),SE(2, 18),SE(2, 19),SE(2, 20),SE(2, 21) ],
            [ SE(3, 0),SE(3, 1),SE(3, 2),SE(3, 3),SE(3, 4),SE(3, 5),SE(3, 6),SE(3, 7),SE(3, 8),SE(3, 9),SE(3, 10),SE(3, 11),SE(3, 12),SE(3, 13),SE(3, 14),SE(3, 15),SE(3, 16),SE(3, 17),SE(3, 18),SE(3, 19),SE(3, 20),SE(3, 21) ],
            [ SE(4, 0),SE(4, 1),SE(4, 2),SE(4, 3),SE(4, 4),SE(4, 5),SE(4, 6),SE(4, 7),SE(4, 8),SE(4, 9),SE(4, 10),SE(4, 11),SE(4, 12),SE(4, 13),SE(4, 14),SE(4, 15),SE(4, 16),SE(4, 17),SE(4, 18),SE(4, 19),SE(4, 20),SE(4, 21) ],
            [ SE(5, 0),SE(5, 1),SE(5, 2),SE(5, 3),SE(5, 4),SE(5, 5),SE(5, 6),SE(5, 7),SE(5, 8),SE(5, 9),SE(5, 10),SE(5, 11),SE(5, 12),SE(5, 13),SE(5, 14),SE(5, 15),SE(5, 16),SE(5, 17),SE(5, 18),SE(5, 19),SE(5, 20),SE(5, 21) ],
            [ SE(6, 0),SE(6, 1),SE(6, 2),SE(6, 3),SE(6, 4),SE(6, 5),SE(6, 6),SE(6, 7),SE(6, 8),SE(6, 9),SE(6, 10),SE(6, 11),SE(6, 12),SE(6, 13),SE(6, 14),SE(6, 15),SE(6, 16),SE(6, 17),SE(6, 18),SE(6, 19),SE(6, 20),SE(6, 21) ]
            ]
        };
        const RCjson = JSON.stringify(RCobject);

        const restAPI = new XMLHttpRequest();
        restAPI.open("PUT", "http://localhost:"+sessionid+"/chromasdk/keyboard");
        restAPI.setRequestHeader("Content-type", "application/json");
        restAPI.send(RCjson);
    }
    catch {
        console.log("Razer Synapse not detected");
    };
};



function wait(ms)  {
    return new Promise( resolve => {
        setTimeout(()=> {resolve('')} ,ms );
    });
};



//A function that can be called to set a horizontal timing event.
async function counter(duration) {
    start_cycle();  //Preparing the Razer Synapse REST-API
    await wait(1500);  //Waiting 1.5 seconds for the request to be completed

    const time = (duration * 1000) / 24;
    let l = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];

    const shading_events_until_black = 24;  //How many parts of the keyboard have turnd black
    let seub = shading_events_until_black;
    function color_ranger(color) {

        const keyboard_horizontal_index = 0;
        let Hi = keyboard_horizontal_index;
        let seub2 = seub;  //Making a copy of "seub" so the original value ("seub") doesn't change (LINE 166)
        for (LED in l) {

            if (seub2 > 0) {
                l[Hi] = color;
            }
            else {
                l[Hi] = "#000000";
            };
            Hi += 1;
            seub2 -= 1;

        };
        PUT_requests(custom_colors_vr(l[0], l[1], l[2], l[3], l[4], l[5], l[6], l[7], l[8], l[9], l[10],
                l[11], l[12], l[13], l[14], l[15], l[16], l[17], l[18], l[19], l[20], l[21], l[22], l[23]));

    };

    while (seub > 0) {
        if (seub > 14) {
            color_ranger("#00ff00");  //The first 10 HTTP requests will be send in "green".
            await wait(time);
        }
        else if (seub > 7) {
            color_ranger("#ffff00");  //The following 7 HTTP requests will be send in "yellow".
            await wait(time);
        }
        else if (seub > 0) {
            color_ranger("#ff0000");  //The last 7 HTTP requests will be send in "red".
            await wait(time);
        };
        seub -= 1;
    };

    PUT_requests(End);
    await wait(50);  //Waiting 50 miliseconds, because we cannot send a "DELETE request" directly after a "PUT request"
    end_cycle();
};

//A function that can be called to display text of your choise (in different colors) on your keyboard!
async function display_text(string, color) {
    start_cycle();  //Preparing the Razer Synapse REST-API
    await wait(1500);  //Waiting 1.5 seconds for the request to be completed

    string = " " + string + " ";  //Adding space so the user has time to see the "first letter" come by, as well as the "last letter"
    const Cstring = string.toUpperCase();

    newText = {                 //This will be used for the next HTTP requests.
        1: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ],
        2: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ],
        3: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ],
        4: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ],
        5: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ],
        6: [ "#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000","#000000" ]
    };

    let oldText = newText;  //So the loop can change the led's coordinates, so that the text will start moving from right to left.
    const remaining_letters = string.length;
    let rl = remaining_letters;  //The more extra letters than the already shown 3 have to be shown, the longer the loop will be to fit all the letters.
    let displayAfterTime = 3;  //Text must be displayed when the "first letter" has reached the left of the keyboard (line 257 + 270)
    while (rl > 0) {

        const letter_grown_width = 0;  //How much of the letter is already displayed
        let lgw = letter_grown_width;  //The higher "lgw", the more space between the letters
        while (lgw < 8) {

            //At the end of this function, one "row of LED's" will be changed in value
            const keyboard_vertical_index = 1;  //   |
            let Vi = keyboard_vertical_index;   //   |
            for (index in oldText) {            //   |
                                                //   ∨
                //At the end of this function, one "LED" will be changed in value
                const keyboard_horizontal_index = 0;
                let Hi = keyboard_horizontal_index;
                for (LED in oldText[Vi]) {
                    try {
                        if (Hi < 23) {
                            //Moving the text from right to left by changing the LED's index with the one on the right of him
                            newText[Vi][Hi] = oldText[Vi][Hi+1];
                        }
                        else if (Hi == 23) {
                            if (lgw < 6) {
                                //The last key will follow by the periodical x-index (determined by "lgw") of the next letter
                                newText[Vi][Hi] = new letters(eval(Cstring[string.length-rl]), color).colored_letter()[Vi][lgw];
                            }
                            else {
                                //A space of "2" (2 comes from { "2" = ["lgw"(8)] - [x-letter-indexes(6)]  }) indexes after each letter is placed.
                                newText[Vi][Hi] = "#000000";
                            };
                        };
                    }
                    catch {
                        newText[Vi][Hi] = "#000000";  //If there is no letter (space, comma, something else), the LED will become black
                    };
                    Hi += 1;
                };

            Vi += 1;

            };
            //The text will be visible when the third letter reached the left of the keyboard.
            if (displayAfterTime < 1) {
                PUT_requests(newText);
                if (displayAfterTime == 0 && lgw == 0) {
                    //When the text is displayed for the first time, "it waits 1 second" before the text starts moving
                    await wait(1000);
                }
                else {
                    //After the first 3 letters stayed at the keyboard for 1 second, it will start moving form right to left with a delay of "0.05 miliseconds"
                    await wait(50);
                };
            };
            oldText = newText;  //So the loop can continue changing the led's coordinates over and over, so that the text will start moving from right to left
            lgw += 1;
        };
        rl -= 1;
        displayAfterTime -= 1;
    };
    
    PUT_requests(End);
    await wait(50);  //Waiting 50 miliseconds, because we cannot send a "DELETE request" directly after a "PUT request"
    end_cycle();
};